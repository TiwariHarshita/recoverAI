from datetime import datetime, timedelta, timezone
from decimal import Decimal
from zoneinfo import ZoneInfo

import pytest

from app.domain.enums import (
    CaseType,
    RecoveryActionType,
)

from app.domain.recovery_case import RecoveryCase

from app.policy import (
    MerchantPolicy,
    MerchantPolicyEngine,
    PolicyContext,
    PolicyDecisionStatus,
    PolicyReason,
    RecoveryActionHistoryItem,
)


# ---------------------------------------------------------------------
# Shared deterministic timestamps
# ---------------------------------------------------------------------

BASE_CREATED_AT = datetime(
    2026,
    8,
    20,
    12,
    0,
    tzinfo=timezone.utc,
)

BASE_NOW = datetime(
    2026,
    8,
    23,
    12,
    0,
    tzinfo=timezone.utc,
)


# ---------------------------------------------------------------------
# Fixtures / helpers
# ---------------------------------------------------------------------

@pytest.fixture
def base_recovery_case() -> RecoveryCase:
    """
    Standard RecoveryCase used by Merchant Policy Engine tests.

    We deliberately use the first available CaseType enum member
    so these tests do not depend on a specific CaseType member name.
    """

    return RecoveryCase(
        merchant_id="merchant_001",
        customer_id="customer_001",
        case_type=list(CaseType)[0],
        amount_at_risk=Decimal("10000.00"),
        attempt_count=1,
        recovery_retry_count=0,
        previous_contacts=0,
        created_at=BASE_CREATED_AT,
        updated_at=BASE_CREATED_AT,
    )


def make_policy(
    merchant_id: str = "merchant_001",
) -> MerchantPolicy:
    """
    Standard merchant policy for tests.
    """

    return MerchantPolicy(
        merchant_id=merchant_id,
        enabled_actions=set(RecoveryActionType),
        sms_enabled=True,
        email_enabled=True,
        max_automated_contacts=3,
        contact_window_days=7,
        max_recovery_retries=2,
        recovery_window_days=7,
        approval_amount_threshold=Decimal("25000.00"),
        timezone="Asia/Kolkata",
    )


def make_context(
    now: datetime = BASE_NOW,
    **kwargs,
) -> PolicyContext:
    """
    Standard runtime policy context.
    """

    return PolicyContext(
        now=now,
        **kwargs,
    )


# ---------------------------------------------------------------------
# Basic allow / block behavior
# ---------------------------------------------------------------------

def test_normal_payment_link_is_allowed(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.CREATE_PAYMENT_LINK,
        policy=policy,
        context=make_context(),
    )

    assert result.status == PolicyDecisionStatus.ALLOW
    assert result.reason == PolicyReason.ACTION_ALLOWED


def test_disabled_action_is_blocked(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    policy.enabled_actions.remove(
        RecoveryActionType.SEND_REMINDER_SMS
    )

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.SEND_REMINDER_SMS,
        policy=policy,
        context=make_context(),
    )

    assert result.status == PolicyDecisionStatus.BLOCK
    assert result.reason == PolicyReason.ACTION_DISABLED


# ---------------------------------------------------------------------
# Channel permissions
# ---------------------------------------------------------------------

def test_sms_channel_can_be_disabled(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    policy.sms_enabled = False

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.SEND_REMINDER_SMS,
        policy=policy,
        context=make_context(),
    )

    assert result.status == PolicyDecisionStatus.BLOCK
    assert result.reason == PolicyReason.CHANNEL_DISABLED


def test_email_channel_can_be_disabled(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    policy.email_enabled = False

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.SEND_REMINDER_EMAIL,
        policy=policy,
        context=make_context(),
    )

    assert result.status == PolicyDecisionStatus.BLOCK
    assert result.reason == PolicyReason.CHANNEL_DISABLED


# ---------------------------------------------------------------------
# Opt-out behavior
# ---------------------------------------------------------------------

def test_customer_opt_out_blocks_customer_action(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    context = make_context(
        customer_opted_out=True
    )

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.CREATE_PAYMENT_LINK,
        policy=policy,
        context=context,
    )

    assert result.status == PolicyDecisionStatus.BLOCK
    assert result.reason == PolicyReason.CUSTOMER_OPTED_OUT


def test_customer_opt_out_allows_human_escalation(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    context = make_context(
        customer_opted_out=True
    )

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.ESCALATE_TO_HUMAN,
        policy=policy,
        context=context,
    )

    assert result.status == PolicyDecisionStatus.ALLOW


def test_customer_opt_out_allows_wait(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    context = make_context(
        customer_opted_out=True
    )

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.WAIT,
        policy=policy,
        context=context,
    )

    assert result.status == PolicyDecisionStatus.ALLOW


# ---------------------------------------------------------------------
# STOP behavior
# ---------------------------------------------------------------------

def test_stop_is_always_available(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    context = make_context(
        customer_opted_out=True,
        dispute_active=True,
        payment_already_recovered=True,
    )

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.STOP,
        policy=policy,
        context=context,
    )

    assert result.status == PolicyDecisionStatus.ALLOW
    assert result.reason == PolicyReason.ACTION_ALLOWED


# ---------------------------------------------------------------------
# Already recovered
# ---------------------------------------------------------------------

def test_payment_already_recovered_blocks_more_recovery(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    context = make_context(
        payment_already_recovered=True
    )

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.CREATE_PAYMENT_LINK,
        policy=policy,
        context=context,
    )

    assert result.status == PolicyDecisionStatus.BLOCK

    assert (
        result.reason
        == PolicyReason.PAYMENT_ALREADY_RECOVERED
    )


# ---------------------------------------------------------------------
# Dispute handling
# ---------------------------------------------------------------------

def test_dispute_blocks_collection_action(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    context = make_context(
        dispute_active=True
    )

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.CREATE_PAYMENT_LINK,
        policy=policy,
        context=context,
    )

    assert result.status == PolicyDecisionStatus.BLOCK
    assert result.reason == PolicyReason.DISPUTE_ACTIVE


def test_dispute_allows_human_escalation(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    context = make_context(
        dispute_active=True
    )

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.ESCALATE_TO_HUMAN,
        policy=policy,
        context=context,
    )

    assert result.status == PolicyDecisionStatus.ALLOW


def test_dispute_allows_wait(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    context = make_context(
        dispute_active=True
    )

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.WAIT,
        policy=policy,
        context=context,
    )

    assert result.status == PolicyDecisionStatus.ALLOW


# ---------------------------------------------------------------------
# Promise-to-pay
# ---------------------------------------------------------------------

def test_active_promise_to_pay_defers_customer_contact(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    promise_due = BASE_NOW + timedelta(days=2)

    context = make_context(
        active_promise_to_pay=True,
        promise_due_at=promise_due,
    )

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.SEND_REMINDER_EMAIL,
        policy=policy,
        context=context,
    )

    assert result.status == PolicyDecisionStatus.DEFER

    assert (
        result.reason
        == PolicyReason.ACTIVE_PROMISE_TO_PAY
    )

    assert result.eligible_at == promise_due


def test_active_promise_to_pay_allows_wait(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    promise_due = BASE_NOW + timedelta(days=2)

    context = make_context(
        active_promise_to_pay=True,
        promise_due_at=promise_due,
    )

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.WAIT,
        policy=policy,
        context=context,
    )

    assert result.status == PolicyDecisionStatus.ALLOW


# ---------------------------------------------------------------------
# RecoverAI retry ceiling
# ---------------------------------------------------------------------

def test_retry_limit_is_enforced(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    base_recovery_case.recovery_retry_count = 2

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.DELAYED_RETRY,
        policy=policy,
        context=make_context(),
    )

    assert result.status == PolicyDecisionStatus.BLOCK
    assert result.reason == PolicyReason.RETRY_LIMIT_REACHED


def test_retry_below_limit_is_allowed(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    base_recovery_case.recovery_retry_count = 1

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.DELAYED_RETRY,
        policy=policy,
        context=make_context(),
    )

    assert result.status == PolicyDecisionStatus.ALLOW


def test_normal_payment_attempt_count_does_not_trigger_recovery_retry_limit(
    base_recovery_case,
):
    """
    attempt_count and recovery_retry_count are intentionally different.

    A customer may have many normal payment attempts without RecoverAI
    itself exceeding its automated retry ceiling.
    """

    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    base_recovery_case.attempt_count = 8
    base_recovery_case.recovery_retry_count = 1

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.DELAYED_RETRY,
        policy=policy,
        context=make_context(),
    )

    assert result.status == PolicyDecisionStatus.ALLOW


# ---------------------------------------------------------------------
# Approval threshold
# ---------------------------------------------------------------------

def test_high_value_action_requires_approval(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    base_recovery_case.amount_at_risk = Decimal("25001.00")

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.CREATE_PAYMENT_LINK,
        policy=policy,
        context=make_context(),
    )

    assert (
        result.status
        == PolicyDecisionStatus.REQUIRE_APPROVAL
    )

    assert (
        result.reason
        == PolicyReason.VALUE_REQUIRES_APPROVAL
    )


def test_exact_approval_threshold_is_allowed(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    base_recovery_case.amount_at_risk = Decimal("25000.00")

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.CREATE_PAYMENT_LINK,
        policy=policy,
        context=make_context(),
    )

    assert result.status == PolicyDecisionStatus.ALLOW


def test_wait_is_exempt_from_approval_threshold(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    base_recovery_case.amount_at_risk = Decimal("100000.00")

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.WAIT,
        policy=policy,
        context=make_context(),
    )

    assert result.status == PolicyDecisionStatus.ALLOW


# ---------------------------------------------------------------------
# Rolling contact-window policy
# ---------------------------------------------------------------------

def test_contact_limit_uses_rolling_window(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    history = [
        RecoveryActionHistoryItem(
            action=RecoveryActionType.SEND_REMINDER_EMAIL,
            occurred_at=BASE_NOW - timedelta(days=1),
        ),
        RecoveryActionHistoryItem(
            action=RecoveryActionType.SEND_REMINDER_SMS,
            occurred_at=BASE_NOW - timedelta(days=2),
        ),
        RecoveryActionHistoryItem(
            action=RecoveryActionType.CREATE_PAYMENT_LINK,
            occurred_at=BASE_NOW - timedelta(days=3),
        ),
    ]

    context = make_context(
        action_history=history,
    )

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.SEND_REMINDER_EMAIL,
        policy=policy,
        context=context,
    )

    assert result.status == PolicyDecisionStatus.BLOCK

    assert (
        result.reason
        == PolicyReason.CONTACT_LIMIT_REACHED
    )


def test_old_contacts_do_not_count_against_rolling_window(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    history = [
        RecoveryActionHistoryItem(
            action=RecoveryActionType.SEND_REMINDER_EMAIL,
            occurred_at=BASE_NOW - timedelta(days=10),
        ),
        RecoveryActionHistoryItem(
            action=RecoveryActionType.SEND_REMINDER_SMS,
            occurred_at=BASE_NOW - timedelta(days=12),
        ),
        RecoveryActionHistoryItem(
            action=RecoveryActionType.CREATE_PAYMENT_LINK,
            occurred_at=BASE_NOW - timedelta(days=15),
        ),
    ]

    context = make_context(
        action_history=history,
    )

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.SEND_REMINDER_EMAIL,
        policy=policy,
        context=context,
    )

    assert result.status == PolicyDecisionStatus.ALLOW


def test_non_contact_actions_do_not_count_toward_contact_limit(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    history = [
        RecoveryActionHistoryItem(
            action=RecoveryActionType.WAIT,
            occurred_at=BASE_NOW - timedelta(days=1),
        ),
        RecoveryActionHistoryItem(
            action=RecoveryActionType.DELAYED_RETRY,
            occurred_at=BASE_NOW - timedelta(days=2),
        ),
        RecoveryActionHistoryItem(
            action=RecoveryActionType.ESCALATE_TO_HUMAN,
            occurred_at=BASE_NOW - timedelta(days=3),
        ),
    ]

    context = make_context(
        action_history=history,
    )

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.SEND_REMINDER_EMAIL,
        policy=policy,
        context=context,
    )

    assert result.status == PolicyDecisionStatus.ALLOW


# ---------------------------------------------------------------------
# Quiet hours
# ---------------------------------------------------------------------

@pytest.mark.parametrize(
    ("hour", "minute", "expected_status"),
    [
        (20, 59, PolicyDecisionStatus.ALLOW),
        (21, 0, PolicyDecisionStatus.DEFER),
        (23, 30, PolicyDecisionStatus.DEFER),
        (2, 0, PolicyDecisionStatus.DEFER),
        (7, 59, PolicyDecisionStatus.DEFER),
        (8, 0, PolicyDecisionStatus.ALLOW),
    ],
)
def test_quiet_hour_boundaries(
    base_recovery_case,
    hour,
    minute,
    expected_status,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    india = ZoneInfo("Asia/Kolkata")

    local_now = datetime(
        2026,
        8,
        23,
        hour,
        minute,
        tzinfo=india,
    )

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.SEND_REMINDER_SMS,
        policy=policy,
        context=make_context(now=local_now),
    )

    assert result.status == expected_status


def test_quiet_hours_return_next_eligible_time(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    india = ZoneInfo("Asia/Kolkata")

    now = datetime(
        2026,
        8,
        23,
        23,
        0,
        tzinfo=india,
    )

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.SEND_REMINDER_SMS,
        policy=policy,
        context=make_context(now=now),
    )

    assert result.status == PolicyDecisionStatus.DEFER
    assert result.reason == PolicyReason.QUIET_HOURS

    assert result.eligible_at == datetime(
        2026,
        8,
        24,
        8,
        0,
        tzinfo=india,
    )


def test_quiet_hours_early_morning_returns_same_day_eligible_time(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    india = ZoneInfo("Asia/Kolkata")

    now = datetime(
        2026,
        8,
        23,
        2,
        0,
        tzinfo=india,
    )

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.SEND_REMINDER_SMS,
        policy=policy,
        context=make_context(now=now),
    )

    assert result.status == PolicyDecisionStatus.DEFER

    assert result.eligible_at == datetime(
        2026,
        8,
        23,
        8,
        0,
        tzinfo=india,
    )


# ---------------------------------------------------------------------
# Recovery window
# ---------------------------------------------------------------------

def test_expired_recovery_window_blocks_automation(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    base_recovery_case.created_at = datetime(
        2026,
        8,
        1,
        12,
        0,
        tzinfo=timezone.utc,
    )

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.CREATE_PAYMENT_LINK,
        policy=policy,
        context=make_context(),
    )

    assert result.status == PolicyDecisionStatus.BLOCK

    assert (
        result.reason
        == PolicyReason.RECOVERY_WINDOW_EXPIRED
    )


def test_expired_recovery_window_allows_human_escalation(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    base_recovery_case.created_at = datetime(
        2026,
        8,
        1,
        12,
        0,
        tzinfo=timezone.utc,
    )

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.ESCALATE_TO_HUMAN,
        policy=policy,
        context=make_context(),
    )

    assert result.status == PolicyDecisionStatus.ALLOW


def test_expired_recovery_window_allows_wait(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    base_recovery_case.created_at = datetime(
        2026,
        8,
        1,
        12,
        0,
        tzinfo=timezone.utc,
    )

    result = engine.evaluate(
        recovery_case=base_recovery_case,
        action=RecoveryActionType.WAIT,
        policy=policy,
        context=make_context(),
    )

    assert result.status == PolicyDecisionStatus.ALLOW


# ---------------------------------------------------------------------
# Fail-closed validation
# ---------------------------------------------------------------------

def test_wrong_merchant_policy_fails_closed(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id="different_merchant"
    )

    with pytest.raises(
        ValueError,
        match="does not belong",
    ):
        engine.evaluate(
            recovery_case=base_recovery_case,
            action=RecoveryActionType.CREATE_PAYMENT_LINK,
            policy=policy,
            context=make_context(),
        )


def test_naive_now_datetime_fails_closed(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    naive_now = datetime(
        2026,
        8,
        23,
        12,
        0,
    )

    context = make_context(
        now=naive_now,
    )

    with pytest.raises(
        ValueError,
        match="timezone-aware",
    ):
        engine.evaluate(
            recovery_case=base_recovery_case,
            action=RecoveryActionType.CREATE_PAYMENT_LINK,
            policy=policy,
            context=context,
        )


def test_naive_case_created_at_fails_closed(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    base_recovery_case.created_at = datetime(
        2026,
        8,
        20,
        12,
        0,
    )

    with pytest.raises(
        ValueError,
        match="RecoveryCase.created_at must be timezone-aware",
    ):
        engine.evaluate(
            recovery_case=base_recovery_case,
            action=RecoveryActionType.CREATE_PAYMENT_LINK,
            policy=policy,
            context=make_context(),
        )


def test_active_promise_without_due_date_fails_closed(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    context = make_context(
        active_promise_to_pay=True,
        promise_due_at=None,
    )

    with pytest.raises(
        ValueError,
        match="promise_due_at is required",
    ):
        engine.evaluate(
            recovery_case=base_recovery_case,
            action=RecoveryActionType.CREATE_PAYMENT_LINK,
            policy=policy,
            context=context,
        )


def test_naive_promise_due_at_fails_closed(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    context = make_context(
        active_promise_to_pay=True,
        promise_due_at=datetime(
            2026,
            8,
            25,
            12,
            0,
        ),
    )

    with pytest.raises(
        ValueError,
        match="promise_due_at must be timezone-aware",
    ):
        engine.evaluate(
            recovery_case=base_recovery_case,
            action=RecoveryActionType.CREATE_PAYMENT_LINK,
            policy=policy,
            context=context,
        )


def test_naive_action_history_timestamp_fails_closed(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    history = [
        RecoveryActionHistoryItem(
            action=RecoveryActionType.SEND_REMINDER_EMAIL,
            occurred_at=datetime(
                2026,
                8,
                22,
                12,
                0,
            ),
        )
    ]

    context = make_context(
        action_history=history,
    )

    with pytest.raises(
        ValueError,
        match="history timestamps",
    ):
        engine.evaluate(
            recovery_case=base_recovery_case,
            action=RecoveryActionType.CREATE_PAYMENT_LINK,
            policy=policy,
            context=context,
        )


def test_invalid_merchant_timezone_fails_closed(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    policy.timezone = "Not/A/Real_Timezone"

    with pytest.raises(
        ValueError,
        match="Unknown merchant timezone",
    ):
        engine.evaluate(
            recovery_case=base_recovery_case,
            action=RecoveryActionType.SEND_REMINDER_SMS,
            policy=policy,
            context=make_context(),
        )


# ---------------------------------------------------------------------
# Candidate batch evaluation
# ---------------------------------------------------------------------

def test_evaluate_candidates_preserves_order(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    actions = [
        RecoveryActionType.WAIT,
        RecoveryActionType.CREATE_PAYMENT_LINK,
        RecoveryActionType.ESCALATE_TO_HUMAN,
    ]

    decisions = engine.evaluate_candidates(
        recovery_case=base_recovery_case,
        actions=actions,
        policy=policy,
        context=make_context(),
    )

    assert [
        decision.action
        for decision in decisions
    ] == actions


def test_allowed_actions_only_returns_auto_allowed_actions(
    base_recovery_case,
):
    engine = MerchantPolicyEngine()

    policy = make_policy(
        merchant_id=base_recovery_case.merchant_id
    )

    base_recovery_case.amount_at_risk = Decimal("50000.00")

    actions = [
        RecoveryActionType.CREATE_PAYMENT_LINK,
        RecoveryActionType.WAIT,
        RecoveryActionType.ESCALATE_TO_HUMAN,
    ]

    allowed = engine.allowed_actions(
        recovery_case=base_recovery_case,
        actions=actions,
        policy=policy,
        context=make_context(),
    )

    assert RecoveryActionType.CREATE_PAYMENT_LINK not in allowed
    assert RecoveryActionType.WAIT in allowed
    assert RecoveryActionType.ESCALATE_TO_HUMAN in allowed